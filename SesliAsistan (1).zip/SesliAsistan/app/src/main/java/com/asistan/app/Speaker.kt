package com.asistan.app

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    private fun setup() {
        val t = tts ?: return
        t.language = Locale("tr", "TR")
        t.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        val male = t.voices?.filter { it.locale.language == "tr" }?.firstOrNull {
            val n = it.name.lowercase(); n.contains("male") && !n.contains("female")
        }
        if (male != null) { t.voice = male; t.setPitch(0.9f) } else t.setPitch(0.72f)
        t.setSpeechRate(0.95f)
    }

    fun say(ctx: Context, s: String) {
        Bus.log(s)
        if (tts == null) {
            pending = s
            tts = TextToSpeech(ctx.applicationContext) {
                if (it == TextToSpeech.SUCCESS) {
                    setup(); ready = true
                    pending?.let { p -> tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "a"); pending = null }
                }
            }
        } else if (ready) tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "a")
    }
}
