package com.asistan.app

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val BG = 0xFF0B0F14.toInt(); private val CARD = 0xFF151B23.toInt(); private val FIELD = 0xFF0F141A.toInt()
    private val ACCENT = 0xFF4FC3F7.toInt(); private val OK = 0xFF66BB6A.toInt(); private val BAD = 0xFFEF6C57.toInt()
    private val DIM = 0xFF9AA7B4.toInt()
    private lateinit var circle: TextView
    private lateinit var state: TextView
    private lateinit var sAcc: TextView; private lateinit var sOv: TextView; private lateinit var sMic: TextView
    private lateinit var logv: TextView
    private var pulse: ValueAnimator? = null
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(CARD, 18)
        setPadding(dp(16), dp(14), dp(16), dp(14)); layoutParams = lp(12)
    }
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(DIM); letterSpacing = 0.1f; setPadding(0, 0, 0, dp(6)) }
    private fun pill(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = bg(0xFF222C38.toInt(), 14)
        setPadding(dp(12), dp(12), dp(12), dp(12)); layoutParams = lp(8); setOnClickListener { f() }
    }
    private fun field(h: String, secret: Boolean = false) = EditText(this).apply {
        hint = h; setHintTextColor(0xFF5E6B78.toInt()); setTextColor(Color.WHITE); textSize = 14f; background = bg(FIELD, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10)); layoutParams = lp(6)
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun chips(vararg cmds: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; layoutParams = lp(6)
        for (c in cmds) addView(TextView(this@MainActivity).apply {
            text = c; textSize = 13f; setTextColor(ACCENT); gravity = Gravity.CENTER; background = bg(0xFF16303D.toInt(), 20)
            setPadding(dp(6), dp(10), dp(6), dp(10)); setOnClickListener { Router.run(this@MainActivity, c) }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
    }
    private fun prefs() = getSharedPreferences("cfg", 0)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(24)) }

        root.addView(TextView(this).apply { text = "Nico"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "sesinle telefonunu yönet"; textSize = 13f; setTextColor(DIM); gravity = Gravity.CENTER })

        circle = TextView(this).apply {
            text = "🎙"; textSize = 42f; gravity = Gravity.CENTER
            setOnClickListener { toggle() }
        }
        root.addView(circle, LinearLayout.LayoutParams(dp(120), dp(120)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(24) })
        state = TextView(this).apply { textSize = 14f; setTextColor(DIM); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4)) }
        root.addView(state)

        val st = card(); st.addView(title("DURUM"))
        sAcc = TextView(this).apply { textSize = 14f }; sOv = TextView(this).apply { textSize = 14f }; sMic = TextView(this).apply { textSize = 14f }
        st.addView(sAcc); st.addView(sOv); st.addView(sMic); root.addView(st)

        val q = card(); q.addView(title("HIZLI KOMUTLAR"))
        q.addView(chips("saat kaç", "fener aç", "fener kapat"))
        q.addView(chips("ileri sar", "sesi aç", "ana ekran"))
        root.addView(q)

        val p = card(); p.addView(title("İZİNLER (SIRAYLA)"))
        p.addView(pill("1  Erişilebilirlik") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        p.addView(pill("2  Mikrofon, rehber, arama, SMS") { requestPermissions(perms, 1) })
        p.addView(pill("3  Yüzen baloncuk") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        p.addView(pill("4  Parlaklık ayarı") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) })
        root.addView(p)

        val s = card(); s.addView(title("KİŞİLİK VE SES"))
        val persona = field("Nico'nun kişiliği").apply { setText(prefs().getString("persona", Ai.DEFAULT_PERSONA)) }
        s.addView(persona)
        s.addView(pill("Kişiliği kaydet") { prefs().edit().putString("persona", persona.text.toString().trim()).apply(); Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show() })
        s.addView(pill("Erkek ses seç (telefonun ses ayarları)") {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        })
        val key = field("Gemini (ücretsiz) ya da Claude anahtarı", true).apply { setText(prefs().getString("key", "")) }
        s.addView(key)
        s.addView(pill("Anahtarı kaydet") { prefs().edit().putString("key", key.text.toString().trim()).apply(); Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show() })
        root.addView(s)

        val t = card(); t.addView(title("KOMUTU YAZARAK DENE"))
        val test = field("örn. saat kaç"); t.addView(test)
        t.addView(pill("Çalıştır") { Router.run(this, test.text.toString()); test.setText("") })
        logv = TextView(this).apply { setTextColor(0xFFC9D1D9.toInt()); textSize = 13f; setPadding(0, dp(10), 0, 0) }
        t.addView(logv); root.addView(t)

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
        Bus.listener = { logv.text = (it + "\n" + logv.text).take(1500) }
    }

    private fun toggle() {
        if (VoiceService.on) stopService(Intent(this, VoiceService::class.java))
        else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(perms, 1); return }
            startForegroundService(Intent(this, VoiceService::class.java))
        }
        circle.postDelayed({ refresh() }, 400)
    }

    private fun setPulse(on: Boolean) {
        pulse?.cancel(); circle.scaleX = 1f; circle.scaleY = 1f
        if (on) pulse = ValueAnimator.ofFloat(1f, 1.1f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { circle.scaleX = it.animatedValue as Float; circle.scaleY = it.animatedValue as Float }; start()
        }
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(c, p, r); refresh() }

    private fun refresh() {
        val on = VoiceService.on
        circle.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) ACCENT else 0xFF2A3441.toInt()) }
        setPulse(on)
        state.text = if (on) "Dinliyor. \"Nico\" de, sonra komutu söyle" else "Kapalı. Başlatmak için mikrofona dokun"
        fun line(v: TextView, ok: Boolean, t: String) { v.text = (if (ok) "●  " else "○  ") + t; v.setTextColor(if (ok) OK else BAD); v.setPadding(0, dp(3), 0, dp(3)) }
        line(sAcc, ControlService.i != null, "Erişilebilirlik " + if (ControlService.i != null) "açık" else "kapalı")
        line(sOv, Settings.canDrawOverlays(this), "Yüzen baloncuk " + if (Settings.canDrawOverlays(this)) "izinli" else "izin yok")
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        line(sMic, mic, "Mikrofon " + if (mic) "izinli" else "izin yok")
    }
}
