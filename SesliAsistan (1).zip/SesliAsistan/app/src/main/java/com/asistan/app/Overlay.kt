package com.asistan.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.*

class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var v: View? = null

    fun show() {
        if (v != null || !Settings.canDrawOverlays(ctx)) return
        val d = ctx.resources.displayMetrics.density
        val s = (52 * d).toInt()
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2E7D32")); setStroke((3 * d).toInt(), Color.WHITE) }
        val view = View(ctx).apply { background = bg; alpha = 0.85f }
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (8 * d).toInt(); y = (160 * d).toInt() }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 10 || Math.abs(e.rawY - dy) > 10) moved = true
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(view, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            true
        }
        wm.addView(view, lp); v = view
        Bus.onState = { awake -> bg.setColor(Color.parseColor(if (awake) "#F9A825" else "#2E7D32")) }
    }

    fun hide() { v?.let { wm.removeView(it) }; v = null; Bus.onState = null }
}
