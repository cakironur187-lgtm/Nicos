package com.asistan.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.media.AudioManager
import java.util.Locale

class VoiceService : Service() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L
    private var running = true
    private var overlay: Overlay? = null
    private val muted = mutableListOf<Int>()
    private val hushOff = Runnable { hush(false) }

    companion object { @Volatile var on = false }

    private fun hush(mute: Boolean) {
        val am = getSystemService(AudioManager::class.java)
        if (mute) {
            for (st in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_MUSIC)) {
                if (st == AudioManager.STREAM_MUSIC && am.isMusicActive) continue
                try { if (!am.isStreamMute(st) && st !in muted) { am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, 0); muted.add(st) } } catch (e: Exception) {}
            }
        } else {
            for (st in muted) try { am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) {}
            muted.clear()
        }
    }
    private fun hushFor(ms: Long) { hush(true); h.removeCallbacks(hushOff); h.postDelayed(hushOff, ms) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("v", "Asistan", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "v").setContentTitle("Nico dinliyor")
            .setContentText("\"Nico\" de ve komutunu söyle").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        overlay = (overlay ?: Overlay(this)).also { it.show() }
        running = true; on = true; listen()
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        hushFor(900)
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { hushFor(900) }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
                override fun onResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                    h.postDelayed({ listen() }, 300)
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"))
        }
    }

    private fun handle(text: String) {
        val t = text.lowercase(Locale("tr"))
        val m = Regex("\\b(nico|niko|nikko|asistan)\\b").find(t)
        when {
            m != null -> {
                val cmd = t.substring(m.range.last + 1).trim().trimStart(',', '.')
                if (cmd.isEmpty()) {
                    awakeUntil = System.currentTimeMillis() + 7000; Bus.state(true); Speaker.say(this, "Dinliyorum")
                    h.postDelayed({ Bus.state(false) }, 7000)
                } else Router.run(this, cmd)
            }
            System.currentTimeMillis() < awakeUntil -> { awakeUntil = 0; Bus.state(false); Router.run(this, t) }
        }
    }

    override fun onDestroy() { running = false; on = false; h.removeCallbacks(hushOff); hush(false); sr?.destroy(); overlay?.hide(); super.onDestroy() }
}
