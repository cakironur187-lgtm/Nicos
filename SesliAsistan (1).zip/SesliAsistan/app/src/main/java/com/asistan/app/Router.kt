package com.asistan.app

import android.Manifest
import android.accessibilityservice.AccessibilityService as AS
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Bus {
    var listener: ((String) -> Unit)? = null
    var onState: ((Boolean) -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())
    fun log(s: String) { h.post { listener?.invoke(s) } }
    fun state(b: Boolean) { h.post { onState?.invoke(b) } }
}

object Router {
    private val main = Handler(Looper.getMainLooper())
    private var torch = false
    private val tr = Locale("tr")

    private fun go(ctx: Context, i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Bus.log("Açılamadı: ${e.message}") } }

    private fun media(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun contactNumber(ctx: Context, spoken: String): String? {
        val w = spoken.trim().substringBefore('\'').substringBefore(' ')
        if (w.length < 2) return null
        try {
            ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val first = c.getString(0).lowercase(tr).substringBefore(' ')
                    if (first.length >= 2 && (w.startsWith(first) || first.startsWith(w))) return c.getString(1)
                }
            }
        } catch (e: SecurityException) { Bus.log("Rehber izni yok") }
        return null
    }

    private fun call(ctx: Context, number: String) {
        val uri = Uri.parse("tel:" + number.replace(" ", ""))
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) go(ctx, Intent(Intent.ACTION_CALL, uri))
        else go(ctx, Intent(Intent.ACTION_DIAL, uri))
    }

    private fun qs(c: ControlService, labels: List<String>) {
        c.performGlobalAction(AS.GLOBAL_ACTION_QUICK_SETTINGS)
        main.postDelayed({
            for (l in labels) if (c.clickText(l)) break
            main.postDelayed({ c.performGlobalAction(AS.GLOBAL_ACTION_BACK) }, 600)
        }, 1000)
    }

    fun run(ctx: Context, raw: String, useAi: Boolean = true) {
        val t = raw.lowercase(tr).trim()
        if (t.isEmpty()) return
        Bus.log("> $t")
        val c = ControlService.i
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun needAcc(f: (ControlService) -> Unit) { if (c == null) Bus.log("Erişilebilirlik izni kapalı") else f(c) }
        val off = t.contains("kapat") || t.contains("kapa")
        when {
            t.startsWith("söyle ") -> Speaker.say(ctx, raw.trim().substringAfter(' '))
            t.startsWith("ileri sar") -> needAcc { it.doubleTap(it.w * 0.85f, it.hgt * 0.4f) }
            t.startsWith("geri sar") -> needAcc { it.doubleTap(it.w * 0.15f, it.hgt * 0.4f) }
            t.contains("durdur") || t.contains("duraklat") || t.contains("oynat") || t.contains("devam") -> media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            t.contains("sonraki") -> media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
            t.contains("önceki") -> media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            t.contains("sesi aç") || t.contains("sesi yükselt") -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            t.contains("sesi kıs") || t.contains("sesi azalt") -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            t.contains("sessize al") -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            t == "geri" || t.contains("geri git") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_BACK) }
            t.contains("ana ekran") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_HOME) }
            t.contains("son uygulama") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_RECENTS) }
            t.contains("bildirim") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_NOTIFICATIONS) }
            t.contains("hızlı ayar") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_QUICK_SETTINGS) }
            t.contains("ekran görüntüsü") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_TAKE_SCREENSHOT) }
            t.contains("kilitle") || t.contains("ekranı kapat") -> needAcc { it.performGlobalAction(AS.GLOBAL_ACTION_LOCK_SCREEN) }
            t.contains("aşağı kaydır") -> needAcc { it.swipe(it.w / 2, it.hgt * 0.7f, it.w / 2, it.hgt * 0.3f) }
            t.contains("yukarı kaydır") -> needAcc { it.swipe(it.w / 2, it.hgt * 0.3f, it.w / 2, it.hgt * 0.7f) }
            t.contains("sola kaydır") -> needAcc { it.swipe(it.w * 0.8f, it.hgt / 2, it.w * 0.2f, it.hgt / 2) }
            t.contains("sağa kaydır") -> needAcc { it.swipe(it.w * 0.2f, it.hgt / 2, it.w * 0.8f, it.hgt / 2) }
            t.startsWith("tıkla ") || t.startsWith("bas ") -> needAcc {
                val x = t.substringAfter(' ')
                if (!it.clickText(x)) Bus.log("Ekranda '$x' yok")
            }
            t.startsWith("yaz ") -> needAcc { if (!it.typeText(raw.trim().substringAfter(' '))) Bus.log("Yazı alanı seçili değil") }
            t.contains("ekranı oku") -> needAcc { val s = it.screenText(); Speaker.say(ctx, if (s.isBlank()) "Ekranda yazı yok" else s.take(800)) }
            t.contains("fener") -> try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                torch = !off; cm.setTorchMode(cm.cameraIdList[0], torch)
            } catch (e: Exception) { Bus.log("Fener hatası") }
            t.contains("parlaklık") -> {
                if (!Settings.System.canWrite(ctx)) go(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                else {
                    val cr = ctx.contentResolver
                    val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
                    val up = t.contains("artır") || t.contains("aç") || t.contains("yükselt")
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (cur + if (up) 50 else -50).coerceIn(5, 255))
                }
            }
            t.contains("wifi") || t.contains("wi-fi") || t.contains("kablosuz") -> needAcc { qs(it, listOf("Wi-Fi", "Wi‑Fi", "Internet", "İnternet")) }
            t.contains("bluetooth") -> needAcc { qs(it, listOf("Bluetooth")) }
            t.contains("uçak modu") -> needAcc { qs(it, listOf("Uçak modu", "Uçak", "Airplane")) }
            t.contains("mobil veri") -> needAcc { qs(it, listOf("Mobil veri", "Mobile data", "Internet", "İnternet")) }
            t.contains("rahatsız etme") -> needAcc { qs(it, listOf("Rahatsız Etmeyin", "Rahatsız etme", "Do Not Disturb")) }
            t.contains("saat kaç") -> Speaker.say(ctx, "Saat " + SimpleDateFormat("HH:mm", tr).format(Date()))
            t.contains("tarih") || t.contains("bugün ayın") -> Speaker.say(ctx, SimpleDateFormat("d MMMM EEEE", tr).format(Date()))
            t.contains("pil") || t.contains("şarj") -> {
                val b = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                Speaker.say(ctx, "Pil yüzde " + b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            }
            t.contains("fotoğraf çek") || t.contains("kamerayı aç") -> {
                go(ctx, Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                if (t.contains("çek")) main.postDelayed({ c?.tap(c.w / 2, c.hgt * 0.9f) }, 2000)
            }
            t.startsWith("internette ") && t.endsWith(" ara") ->
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(t.removePrefix("internette ").removeSuffix(" ara")))))
            (t.startsWith("youtube'da ") || t.startsWith("youtubeda ")) && t.endsWith(" ara") ->
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(t.substringAfter(' ').removeSuffix(" ara")))))
            t.contains("yol tarifi") ->
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(t.substringBefore(" yol tarifi").replace(Regex("'?[eaı]$"), "")))))
            t.startsWith("zamanlayıcı") -> Regex("(\\d+)").find(t)?.let {
                go(ctx, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, it.value.toInt() * 60).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            t.startsWith("alarm ") -> Regex("(\\d{1,2})[: ]?(\\d{2})?").find(t)?.let {
                go(ctx, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, it.groupValues[1].toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, it.groupValues[2].ifEmpty { "0" }.toInt()))
            }
            t.startsWith("sms ") -> {
                val p = t.removePrefix("sms ").split(" ", limit = 2)
                val num = contactNumber(ctx, p[0])
                if (num == null || p.size < 2) Bus.log("Kişi ya da mesaj yok")
                else try {
                    val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                    sm.sendTextMessage(num, null, p[1], null, null); Speaker.say(ctx, "Mesaj gönderildi")
                } catch (e: Exception) { Bus.log("SMS izni yok") }
            }
            t.startsWith("ara ") && t.drop(4).replace(" ", "").all { it.isDigit() || it == '+' } -> call(ctx, t.drop(4))
            t.endsWith(" ara") -> {
                val num = contactNumber(ctx, t.removeSuffix(" ara"))
                if (num != null) call(ctx, num) else if (useAi) askAi(ctx, t) else Bus.log("Kişi bulunamadı")
            }
            t.endsWith(" aç") -> if (!openApp(ctx, t.removeSuffix(" aç").trim()) && useAi) askAi(ctx, t)
            else -> if (useAi) askAi(ctx, t) else Bus.log("Anlaşılmadı")
        }
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null &&
                pm.getApplicationLabel(it).toString().lowercase(tr).contains(name)
        } ?: return false
        go(ctx, pm.getLaunchIntentForPackage(app.packageName)!!)
        return true
    }

    private fun askAi(ctx: Context, t: String) {
        val key = ctx.getSharedPreferences("cfg", 0).getString("key", "") ?: ""
        val persona = ctx.getSharedPreferences("cfg", 0).getString("persona", Ai.DEFAULT_PERSONA) ?: Ai.DEFAULT_PERSONA
        if (key.isEmpty()) { Bus.log("Anlaşılmadı (API anahtarı yok)"); return }
        Thread {
            try {
                val lines = Ai.ask(key, t, persona).lines().map { it.trim() }.filter { it.isNotEmpty() }
                Bus.log("AI: " + lines.joinToString(" → "))
                lines.forEachIndexed { i, l -> main.postDelayed({ run(ctx, l, false) }, i * 1800L) }
            } catch (e: Exception) { Bus.log("AI hatası: ${e.message}") }
        }.start()
    }
}
