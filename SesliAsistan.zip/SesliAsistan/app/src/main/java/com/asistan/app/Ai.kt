package com.asistan.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    const val DEFAULT_PERSONA = "Sakin, sıcak ve akıcı; kısa, yumuşak cümlelerle, su gibi doğal konuşur."
    private const val BASE = """Kullanıcının Türkçe isteğini telefonun anlayacağı komutlara çevir. Her satıra TEK komut yaz, gerekirse birden çok satır (sırayla yürütülür). Başka hiçbir şey yazma.
Komutlar: ileri sar | geri sar | durdur | oynat | sonraki | önceki | sesi aç | sesi kıs | sessize al | geri | ana ekran | son uygulamalar | bildirimleri aç | hızlı ayarlar | ekran görüntüsü | ekranı kilitle | aşağı kaydır | yukarı kaydır | sola kaydır | sağa kaydır | tıkla <ekrandaki yazı> | yaz <metin> | ara <numara> | <kişi adı> ara | sms <kişi> <mesaj> | alarm <saat> <dakika> | zamanlayıcı <n> dakika | <uygulama adı> aç | fener aç | fener kapat | parlaklığı artır | parlaklığı azalt | wifi aç/kapat | bluetooth aç/kapat | uçak modu aç/kapat | mobil veri aç/kapat | rahatsız etme aç/kapat | saat kaç | pil kaç | ekranı oku | fotoğraf çek | internette <konu> ara | youtube'da <konu> ara | <yer> yol tarifi | söyle <cümle>"""

    fun ask(key: String, text: String, persona: String = DEFAULT_PERSONA): String {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 20000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 300).put("system", BASE + "\nKişilik (Nico): " + persona + "\nİstek bir komut değil de sohbet, soru ya da selamsa tek satırda 'söyle <cümle>' yaz; cümleyi bu kişilikle, kısa kur.")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("HTTP ${c.responseCode}")
        return JSONObject(s).getJSONArray("content").getJSONObject(0).getString("text").trim()
    }
}
