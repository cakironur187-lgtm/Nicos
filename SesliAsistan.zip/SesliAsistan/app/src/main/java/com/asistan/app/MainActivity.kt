package com.asistan.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logv: TextView

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun pkg() = Uri.parse("package:$packageName")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F1115"))
            setPadding((16 * d).toInt(), (36 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
        }
        root.addView(TextView(this).apply { text = "Nico"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#8FD3A8")); setPadding(0, (8 * d).toInt(), 0, (8 * d).toInt()) }
        root.addView(status)
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS)
        root.addView(btn("1) Erişilebilirlik izni") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2) Mikrofon, rehber, arama, SMS izinleri") { requestPermissions(perms, 1) })
        root.addView(btn("3) Yüzen baloncuk izni") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg())) })
        root.addView(btn("4) Parlaklık ayarı izni") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg())) })
        root.addView(btn("▶ Dinlemeyi başlat") { startForegroundService(Intent(this, VoiceService::class.java)); refresh() })
        root.addView(btn("■ Durdur") { stopService(Intent(this, VoiceService::class.java)); refresh() })
        val persona = EditText(this).apply {
            hint = "Nico'nun kişiliği"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setText(getSharedPreferences("cfg", 0).getString("persona", Ai.DEFAULT_PERSONA))
        }
        root.addView(persona)
        root.addView(btn("Kişiliği kaydet") { getSharedPreferences("cfg", 0).edit().putString("persona", persona.text.toString().trim()).apply() })
        val key = EditText(this).apply {
            hint = "Claude API anahtarı (serbest cümleler için)"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setText(getSharedPreferences("cfg", 0).getString("key", ""))
        }
        root.addView(key)
        root.addView(btn("Anahtarı kaydet") { getSharedPreferences("cfg", 0).edit().putString("key", key.text.toString().trim()).apply() })
        val test = EditText(this).apply { hint = "Komutu yazarak dene"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE) }
        root.addView(test)
        root.addView(btn("Çalıştır") { Router.run(this, test.text.toString()); test.setText("") })
        logv = TextView(this).apply { setTextColor(Color.parseColor("#C9D1D9")); textSize = 13f }
        root.addView(ScrollView(this).apply { addView(logv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        Bus.listener = { logv.text = it + "\n" + logv.text }
    }

    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        status.text = "Erişilebilirlik: " + (if (ControlService.i != null) "AÇIK" else "KAPALI") +
            "\nBaloncuk: " + (if (Settings.canDrawOverlays(this)) "izin var" else "izin yok") +
            "\nUyandırma: \"Nico, ileri sar\""
    }
}
