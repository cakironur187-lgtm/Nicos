package com.asistan.app

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    fun say(ctx: Context, s: String) {
        Bus.log(s)
        if (tts == null) {
            pending = s
            tts = TextToSpeech(ctx.applicationContext) {
                if (it == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("tr", "TR"); ready = true
                    pending?.let { p -> tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "a"); pending = null }
                }
            }
        } else if (ready) tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "a")
    }
}
